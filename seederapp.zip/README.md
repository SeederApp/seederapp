seederapp
=========

SeederApp repo


== Ripple Settings using a simulator ==

=[Build]=

SDK Path:
C:\Program Files (x86)\Research In Motion\BlackBerry 10 WebWorks SDK 1.0.4.11

Project Root:
C:\Users\<Username>\RippleSites\Seeder\trunk

Archive Name:
Seeder

Output Folder:
C:\Users\<Username>\RippleSites\Seeder\trunk\Packaged

-

=[Sign]=

Leave all fields empty if running in the simulator.

-

=[Launch]=

Target:
Simulator

Device IP:
You can obtain in the simulator at: Settings > About > Network (category) > IPv4

Device Password:
(Empty)
